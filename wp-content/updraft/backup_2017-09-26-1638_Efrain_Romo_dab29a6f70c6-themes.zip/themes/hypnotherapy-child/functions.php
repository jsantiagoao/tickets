<?php
/**
 * Child-Theme functions and definitions
 */

?>